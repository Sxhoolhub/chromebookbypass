				REPOSITORY OF GAMES 
Note: I own none of these games, this document is protected under the GPL license, it also includes games with a GPL License that have been included in this project with a GPL License.
These games either run by themselves or in a folder depending on other .js and .css files.
I hope you like my first repository.
Under the GPL License anyone can add games as they so choose, but any games in this repository are protected by GPL, if you don't have a LICENSE then you can have your games owned directly by me.
We are looking for Emulators, roms can be included in the MD with seperate links.
DO NOT ADD PULL REQUESTS FOR ROMS!!!!!!
ROMS ARE OWNED BY THEIR RESPECTIVE OWNERS AND ARE LICENSED PRIVATELY.
All pull requests of roms are to be declined.

ROM SITES (I don't own these):
https://the-eye.eu/public/rom/
